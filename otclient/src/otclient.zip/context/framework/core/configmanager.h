/*
 * Copyright (c) 2010-2026 OTClient <https://github.com/edubart/otclient>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#pragma once

#include "config.h"

struct GraphicsConfig
{
    uint16_t maxAtlasSize = 8192;
    int16_t  mapAtlasSize = 0;
    int16_t foregroundAtlasSize = 2048;
};

struct FontConfig
{
    std::string widget;
    std::string staticText;
    std::string animatedText;
    std::string creatureText;
};

struct PublicConfig
{
    GraphicsConfig graphics;
    FontConfig font;
};

// @bindsingleton g_configs
class ConfigManager
{
public:
    void init();
    void terminate();

    ConfigPtr getSettings();
    ConfigPtr get(const std::string& file);

    ConfigPtr create(const std::string& file);
    ConfigPtr loadSettings(const std::string& file);
    ConfigPtr load(const std::string& file);

    bool unload(const std::string& file);
    void remove(const ConfigPtr& config);

    void saveSettings();

    const PublicConfig& getPublicConfig() const { return m_publicConfig; }
    void loadPublicConfig(const std::string& file);

protected:
    ConfigPtr m_settings;

private:
    std::list<ConfigPtr> m_configs;
    PublicConfig m_publicConfig;
};

extern ConfigManager g_configs;
